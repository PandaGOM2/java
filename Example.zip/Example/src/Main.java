import java.util.ArrayList;
import java.util.List;

public class Main {
	
	private static List<User> users = new ArrayList<>();
	private static List<Account> accounts = new ArrayList<>();
	
	public static final String[] BANKS = {
			"원광은행"
	};
	private static final User User = null;
	
	public static User nowLogin = null;
	
	public static LoginFrame loginFrame;
	public static MainFrame mainFrame;
	
	
	public static void main(String[] args) {
		Main main = new Main();
        main.initialize();
		
	}
	 public void initialize() {
	        loginFrame = new LoginFrame();
	        mainFrame = new MainFrame();

	        // 예시로 사용자와 계좌를 생성하고 리스트에 추가
	        User user1 = new User("user1", "password1");
	        users.add(user1);
	        User user2 = new User("user2", "password2");
	        users.add(user2);

	        Account account1 = new Account(user1, "원광은행");
	        accounts.add(account1);
	        Account account2 = new Account(user2, "원광은행");
	        accounts.add(account2);

	        loginFrame.setVisible(true);
	    }
	public static User getUser(String id) {
		for(User user : users)
			if(user.getId().equals(id))
				return user;
		return null;
	}
	
	public static Account getAccount(String number, String bank) {
		for(Account account : accounts)
			if(account.getNumber().equals(number) && account.getBank().equals(bank))
				return account;
		return null;
	}

	public static boolean signUp(String id, String pw) {
		User user = getUser(id);
		if(user != null) return false;
		user = new User(id, pw);
		users.add(user);
		return true;
	}
	
	public static boolean login(String id, String pw) {
		User user = getUser(id);
		if(user == null) return false;
		if(!user.tryLogin(pw)) return false;
		return true;
	}

	public static Account createAccount(User user, String bank) {
		Account account = new Account(user, bank);
		accounts.add(account);
		return account;
	}

	
	public static List<Account> getAccounts(User user){
			 List<Account> result = new ArrayList<>();
			 for(Account account : accounts)
			   if(account.getOwner().equals(user))
			     result.add(account);
		  return result;
			}
		
}
