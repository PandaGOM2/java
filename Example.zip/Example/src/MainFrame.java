import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame {
	private JTextField txtOR;
	private JTextField txtOr_1;
	/**
	 * Create the frame.
	 */
	public MainFrame() {
		getContentPane().setForeground(new Color(255, 255, 255));
		getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		setTitle("원광은행");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 553, 395);
		getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.nowLogin = null;
				Main.mainFrame.setVisible(false);
				Main.loginFrame.setVisible(true);
			}
		});
		btnNewButton.setBounds(436, 308, 91, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("입금");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String amountText = txtOR.getText();
				String amountText1 = txtOr_1.getText();
				if (!amountText.isEmpty()&&!amountText.isEmpty()) {
					try {
						double amount = Double.parseDouble(amountText);
						Main.getAccounts(null);
						
						JOptionPane.showMessageDialog(MainFrame.this, "입금이 완료되었습니다.");
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(MainFrame.this, "유효한 금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(MainFrame.this, "금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBounds(22, 146, 142, 40);
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("출금");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String amountText = txtOR.getText();
				String amountText1 = txtOr_1.getText();
				if (!amountText.isEmpty()&&!amountText.isEmpty()) {
					try {
						double amount = Double.parseDouble(amountText);
						Main.getAccounts(null);
							// 출금 처리 후에 적절한 메시지를 보여줄 수 있습니다.
						JOptionPane.showMessageDialog(MainFrame.this, "출금이 완료되었습니다.");
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(MainFrame.this, "유효한 금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(MainFrame.this, "금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		});
		btnNewButton_2.setBounds(176, 146, 142, 40);
		getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("계좌이체");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String amountText = txtOR.getText();
				String amountText1 = txtOr_1.getText();
				if (!amountText.isEmpty()&&!amountText.isEmpty()) {
					try {
						double amount = Double.parseDouble(amountText);
						Main.getAccounts(null);
							// 출금 처리 후에 적절한 메시지를 보여줄 수 있습니다.
						JOptionPane.showMessageDialog(MainFrame.this, "계좌이체가 완료되었습니다.");
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(MainFrame.this, "유효한 금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(MainFrame.this, "잘못된 계좌입니다", "오류", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_3.setBounds(329, 146, 142, 40);
		getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("계좌출력");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String amountText = txtOR.getText();
				if (!amountText.isEmpty()) {
		            try {
		                double amount = Double.parseDouble(amountText);
		                // Main.getAccounts 메서드를 호출하여 계좌 정보를 가져옴
		                Main.getAccounts(null);

		                // 계좌 정보를 출력하는 로직 추가
		                StringBuilder output = new StringBuilder();
		                for (Account account : Main.getAccounts(null)) {
		                    output.append("계좌번호: ").append(account.getNumber())
		                          .append(", 잔액: ").append(account.getBalance())
		                          .append("\n");
		                }

		                // 계좌 정보를 보여줄 수 있는 다이얼로그를 표시
		                JOptionPane.showMessageDialog(MainFrame.this, output.toString(), "계좌 출력", JOptionPane.INFORMATION_MESSAGE);
		            } catch (NumberFormatException ex) {
		                JOptionPane.showMessageDialog(MainFrame.this, "유효한 금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
		            }
		        } else {
		            JOptionPane.showMessageDialog(MainFrame.this, "금액을 입력해주세요.", "오류", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});
		btnNewButton_4.setBounds(22, 239, 142, 40);
		getContentPane().add(btnNewButton_4);
		
		txtOR = new JTextField();
		txtOR.setForeground(SystemColor.desktop);
		txtOR.setFont(new Font("HY헤드라인M", Font.PLAIN, 12));
		txtOR.setHorizontalAlignment(JTextField.CENTER);
		txtOR.setText("Money");
		txtOR.setBounds(152, 68, 206, 40);
		getContentPane().add(txtOR);
		txtOR.setColumns(10);
		
		txtOr_1 = new JTextField();
		txtOr_1.setText("User");
		txtOr_1.setHorizontalAlignment(SwingConstants.CENTER);
		txtOr_1.setForeground(Color.BLACK);
		txtOr_1.setFont(new Font("HY헤드라인M", Font.PLAIN, 12));
		txtOr_1.setColumns(10);
		txtOr_1.setBounds(152, 10, 206, 40);
		getContentPane().add(txtOr_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(187, 239, 196, 101);
		getContentPane().add(textArea);
	}
}
