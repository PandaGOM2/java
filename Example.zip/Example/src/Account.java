import java.util.Random;

public class Account {

	private static final Random random = new Random();
	
	private String number;
	private String bank;
	private int balance;
	private User owner;
	
	//계좌 랜덤 생성
	private static String createAccountNumber() {
		String aClass = Integer.toString(random.nextInt(1000)+1);
		while(aClass.length() < 4) aClass = "0" + aClass;
		String bClass = Integer.toString(random.nextInt(10)+1);
		while(bClass.length() < 2) bClass = "0" + bClass;
		String cClass = Integer.toString(random.nextInt(1000000)+1);
		while(cClass.length() < 7) cClass = "0" + cClass;
		return aClass + "-" + bClass + "-" + cClass;
	}
	
	//파일에서 불러올때
	public Account(String number, String bank, int balance, User user) {
		this.number = number;
		this.bank = bank;
		this.balance = balance;
		this.owner = user;
	}
	//새롭게
	public Account(User user, String bank) {
		this(createAccountNumber(), bank, 0, user);
	}
	//입금
	public void deposit(int balance) {
		this.balance += balance;
	}

	//출금
	//0 - 성공
	//1 - 잔액부족
	public int withDraw(int balance) {
		if(this.balance < balance) return 1;
		this.balance -= balance;
		return 0;
	}
	//계좌이체 - 아이디로 할 때 
	//0 - 성공
	//1 - 계좌 없음
	//2 - 잔액 부족
	public int transfer(String number, String bank, int balance) {
		Account account = Main.getAccount(number, bank);
		return transfer(account, balance);
	}
	// 계좌이체 - 계좌번호로 할 때
	//0 - 성공
	//1 - 계좌 없음
	//2 - 잔액 부족
	public int transfer(Account account, int balance) {
		if(account == null) return 1;
		if(this.balance < balance) return 2;
		this.balance -= balance;
		account.balance += balance;
		return 0;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}
	
}
