import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setTitle("원광은행");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 238, 188);
		getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(12, 10, 193, 21);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(12, 41, 193, 21);
		
		JButton btnNewButton = new JButton("Log In");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Main.login(textField.getText(), passwordField.getText())){
					JOptionPane.showMessageDialog(null, "로그인 성공", "로그인", JOptionPane.PLAIN_MESSAGE);
					Main.nowLogin = Main.getUser(textField.getText());
					Main.loginFrame.setVisible(false);
					Main.mainFrame.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 일치하지 않습니다.", "로그인", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(12, 68, 193, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Sign Up");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Main.signUp(textField.getText(), passwordField.getText())) {
					JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.", "회원가입", JOptionPane.PLAIN_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "이미 가입된 아이디입니다.", "회원가입", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBounds(12, 101, 193, 23);
		getContentPane().add(btnNewButton_1);
		
		getContentPane().add(passwordField);
	}
}
